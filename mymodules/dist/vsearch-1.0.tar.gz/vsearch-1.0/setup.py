from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Devansh',
    author_email='devansh233@gmail.com',
    py_modules=['vsearch']
)
    
